from django.contrib import admin
from .models import University

admin.site.register(University)
